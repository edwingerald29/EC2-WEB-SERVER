#!/bin/bash
# ============================================================
# setup.sh — EC2 Web Server Setup Script
# Author  : Edwin Jerald S
# Purpose : Installs and configures Apache web server on
#           Amazon Linux 2023 EC2 instance
# Usage   : sudo bash setup.sh
# ============================================================

set -e  # Exit immediately if any command fails

echo "============================================"
echo " EC2 Web Server Setup — Edwin Jerald S"
echo "============================================"

# Step 1: Update all system packages
echo ""
echo "[1/5] Updating system packages..."
sudo yum update -y
echo "Done."

# Step 2: Install Apache web server
echo ""
echo "[2/5] Installing Apache (httpd)..."
sudo yum install httpd -y
echo "Done."

# Step 3: Start Apache and enable it on reboot
echo ""
echo "[3/5] Starting Apache and enabling auto-start..."
sudo systemctl start httpd
sudo systemctl enable httpd
echo "Done."

# Step 4: Copy web files to Apache root directory
echo ""
echo "[4/5] Deploying web files..."
sudo cp index.html /var/www/html/index.html
sudo chown apache:apache /var/www/html/index.html
sudo chmod 644 /var/www/html/index.html
echo "Done."

# Step 5: Verify Apache is running
echo ""
echo "[5/5] Verifying Apache status..."
sudo systemctl status httpd --no-pager

echo ""
echo "============================================"
echo " Setup Complete!"
echo " Open your Elastic IP in a browser to verify"
echo "============================================"
